/* 
 * File:   switch.h
 * Author: TEAM 207
 * Created on 10/28/2015
 */

#ifndef SWITCH_H
#define	SWITCH_H
#define SWR PORTDbits.RD6

void initSW();


#endif	/* SWITCH_H */

