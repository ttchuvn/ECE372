/* 
 * File:   keypad.h
 * Author: TEAM 206
 *
 * Created on 10/22/2015
 */

#ifndef KEYPAD_H
#define	KEYPAD_H


void initKeypad(void);
char scanKeypad(int Colk, int Rowk);

#endif	/* KEYPAD_H */

