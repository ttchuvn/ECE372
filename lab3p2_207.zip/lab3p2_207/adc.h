/* 
 * File:   adc.h
 * Author: TEAM 207 *
 * Created on 10/28/2015
 */

#ifndef ADC_H
#define	ADC_H

void initADC();

#endif	/* ADC_H */
