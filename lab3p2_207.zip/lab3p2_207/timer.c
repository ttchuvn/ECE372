/*
 * File:   timer.c
 * Author: TEAM 207
 *
 * Created on 10/28/2015
 */
#include <xc.h>
#include "timer.h"
#include "interrupt.h"


void initTimer1() {
    TMR1 = 0x0000;               //Clear TMR1
    T1CONbits.TCKPS = 1;        //Init pre-scaler 8
    T1CONbits.TCS = 0;          //Setting the oscillator
    IFS0bits.T1IF = 0;      //Put the flag down
    T1CONbits.ON = 0;       //Turn timer off
}

void delayUs(unsigned int delay){
    //TODO: Create a delay using timer 2 for "delay" microseconds.
    if (delay == 0) return;
    TMR1 = 0x0000;               //Clear TMR1
    PR1 = delay * 8;          //prescalar to 8
    IFS0bits.T1IF = 0;      //Put flag down
    T1CONbits.ON = 1;        //Turn timer on
    while (IFS0bits.T1IF == 0); //Wait for change
    T1CONbits.ON = 0;       //Turn timer off
}
//Timer2 is used for the PWM
void initTimer2(){
    TMR2 = 0x0000;
    PR2 = 1023;
    T2CONbits.TCKPS = 0;        //Init pre-scalar 
    T2CONbits.TCS = 0;      //Setting the oscillator
    T2CONbits.ON = 1;       //Turn timer on
}

void initTimer3(){
    TMR3 = 0x0000;
    PR3 = 1023;
    T3CONbits.TCKPS = 0;        //Init pre-scalar 
    T3CONbits.TCS = 0;      //Setting the oscillator
    T3CONbits.ON = 1;       //Turn timer on
}
//Uses timer 2
/*void delayUs2(unsigned int delay){
    TMR1 = 0;
    PR1 = 1023;
    //PR1 = 5*delay;
    IFS0bits.T2IF = 0;
    T1CONbits.TCKPS = 1;
    disableInterrupts();
    T1CONbits.TON = 1;
    while(IFS0bits.T1IF == 0);
    T1CONbits.TON = 0;
    enableInterrupts();
}*/