/* 
 * File:   led.h
 * Author: gvanhoy
 * Student: Toan Chu
 * Created on August 27, 2015, 3:15 PM
 */

#ifndef LED_H
#define	LED_H

void initLEDs();
void turnOnLED(int led);
void turnOffLED(int led);

#endif	/* LED_H */

