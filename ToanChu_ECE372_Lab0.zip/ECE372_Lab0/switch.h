/* 
 * File:   switch.h
 * Author: gvanhoy
 * Student: Toan Chu
 * Created on August 27, 2015, 3:12 PM
 */

#ifndef SWITCH_H
#define	SWITCH_H

void initSwitches();

#endif	/* SWITCH_H */

